/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author neuzo
 */
@WebServlet(urlPatterns = {"/Details"})
public class Details extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws java.lang.ClassNotFoundException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
      
        try (PrintWriter out = response.getWriter()) {
       
           Class.forName("org.apache.derby.jdbc.ClientDriver");  
  
//step2 create  the connection object  
Connection con=DriverManager.getConnection(  
"jdbc:derby://localhost:1527/mindhealthcare;create=true","raj","raj");  
 
//step3 create the statement object  
Statement stmt=con.createStatement();  
  HttpSession session=request.getSession(false);  
String email=(String)session.getAttribute("email");  
       
 
  

//step4 execute query  
String query="select * from RAJ.REGISTER where email='"+email+"'";
 
        
ResultSet rs=stmt.executeQuery(query);  
while(rs.next())  {
   
    
    StringBuffer sb=new StringBuffer();
    sb.append("<table><tr bgcolor=\"#8FBC8F\"><td>"+
            rs.getInt(1)+"</td><td>"+
            rs.getString(2)+"</td><td>"+
 rs.getString(2)+"</td><td>"+
             rs.getString(3)+"</td><td>"+ 
            rs.getString(4)+"</td><td></tr></table>");
    System.out.print(sb);
out.print(sb.toString());

}

//step5 close the connection object  
con.close();  
  
}
         
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try{
        processRequest(request, response);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
