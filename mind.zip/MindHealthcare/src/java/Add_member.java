/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author neuzo
 */
@WebServlet(urlPatterns = {"/Add_member"})
public class Add_member extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Add_member</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Add_member at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
         PrintWriter out = response.getWriter();
          //out.print("found"); 
        //step1 load the driver class  
try{Class.forName("org.apache.derby.jdbc.ClientDriver");  
  
//step2 create  the connection object  
Connection con=DriverManager.getConnection(  
"jdbc:derby://localhost:1527/mindhealthcare;create=true","raj","raj");  
  
//step3 create the statement object  
Statement stmt=con.createStatement();  
 String fname=request.getParameter("fname");
 String lname=request.getParameter("lname");
 String pass1=request.getParameter("pass");
 String pass=request.getParameter("password");
 String type=request.getParameter("type");
  String email=request.getParameter("email");

 
if(pass.equals(pass1)){
stmt.executeUpdate("INSERT INTO register(fname,lname,email,password,type)VALUES('"+fname+"','"+lname+"','"+email+"','"+pass1+"','"+type+"')");
out.print(fname+" "+"has been registered as a"+" "+type);
}
else {
    out.print("Password Mismatch");
} 

//step5 close the connection object  
con.close();  
  
}catch(Exception e){ System.out.println(e);} 
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
