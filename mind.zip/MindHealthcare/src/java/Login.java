/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;


@WebServlet(urlPatterns = {"/Login"})
public class Login extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
          //out.print("found"); 
        //step1 load the driver class  
try{Class.forName("org.apache.derby.jdbc.ClientDriver");  
  
//step2 create  the connection object  
Connection con=DriverManager.getConnection(  
"jdbc:derby://localhost:1527/mindhealthcare;create=true","raj","raj");  
  
//step3 create the statement object  
Statement stmt=con.createStatement();  
 String email=request.getParameter("Name");
   HttpSession session=request.getSession();  
   session.setAttribute("email",email);  
 String pass=request.getParameter("Password");

//step4 execute query  
String query="select * from REGISTER where email='"+email+"' and password='"+pass+"'";
ResultSet rs=stmt.executeQuery(query);  
if(rs.next())  {
    String s=rs.getString(6);
    out.print(s);
   if(s.equals("Admin")){
        response.sendRedirect("admin.jsp");
    }
    else if(s.equals("User")){
        response.sendRedirect("user.jsp");
    }
    else if(s.equals("Doctor")){
     response.sendRedirect("doctor.jsp");
    } 
   
}

//step5 close the connection object  
con.close();  
  
}catch(Exception e){ System.out.println(e);}  

   }
} 
        
        
       
        
  